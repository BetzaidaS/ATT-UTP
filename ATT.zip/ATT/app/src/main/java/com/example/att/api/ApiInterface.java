package com.example.att.api;

import com.example.att.api.request.RequestUser;
import com.example.att.api.response.UserResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {

    @POST("login")
    Call<UserResponse> login(@Query("email") String email, @Query("pass") String pass);


}
