package com.example.att.components.auth;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.att.R;
import com.example.att.api.ApiService;
import com.example.att.api.request.RequestUser;
import com.example.att.api.response.UserResponse;
import com.example.att.database.DatabaseManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    EditText userEmail, userPassword;
    DatabaseManager database;
    MediaPlayer click, music;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = new DatabaseManager(getApplicationContext());

        userEmail = (EditText) findViewById(R.id.email);
        userPassword = (EditText) findViewById(R.id.password);


        verifyUserSession();
    }

    private void verifyUserSession() {
        UserResponse user = database.getUserSession();
        if (user != null) {
            startActivity(new Intent(getApplicationContext(), AuthMessageActivity.class));
        }
    }

    public void performUserLogin(View v) {
        try {
            String email = userEmail.getText().toString();
            String pass = userPassword.getText().toString();

            Call<UserResponse> response = ApiService.getApiService().login(email,pass);
            response.enqueue(new Callback<UserResponse>() {
                @Override
                public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                    if (response.isSuccessful()) {
                        UserResponse estudiante = response.body();
                        if (estudiante != null) {
                            RequestUser user = new RequestUser(estudiante.getId_usuario(), estudiante.getEmail(), "", estudiante.getNombre());

                            database.saveUserSession(estudiante);

                            Toast.makeText(getApplicationContext(), "Login Exitoso", Toast.LENGTH_LONG).show();

                            Intent i = new Intent(getApplicationContext(), AuthMessageActivity.class);
                            i.putExtra("UserId", estudiante.getId_usuario());
                            i.putExtra("Nombre", estudiante.getNombre());
                            i.putExtra("Apellido", estudiante.getApellido());
                            i.putExtra("Cedula", estudiante.getCedula());
                            i.putExtra("Correo", estudiante.getEmail());
                           // i.putExtra("Fecha",estudiante.getCreated_at());

                            startActivity(i);
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Error Al Iniciar Sesión", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<UserResponse> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), "Error Al Iniciar Sesión", Toast.LENGTH_LONG).show();
                    int x = 1;
                }
            });
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Error Al Iniciar Sesión", Toast.LENGTH_LONG).show();
            int x = 1;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        music.pause();
    }
}